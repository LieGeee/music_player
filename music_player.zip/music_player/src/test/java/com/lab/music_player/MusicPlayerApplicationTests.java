package com.lab.music_player;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MusicPlayerApplicationTests {

	@Test
	void contextLoads() {
	}

}
